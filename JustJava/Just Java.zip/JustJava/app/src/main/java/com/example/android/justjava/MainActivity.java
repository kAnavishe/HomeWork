package com.example.android.justjava;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    public String name = "Yojin";
    public String quantity ="Quantity: ";
    public String total = "Total: ";
    public String closeThankYou = "Thank You!";

    public int mNumberOfCoffees = 0;
    public static final int PRICE_PER_CUP = 5;
    public static final int PAPER_CUP_CHARGE = 2;
    private int originalColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View.OnClickListener orderButton = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finalOrder();
            }
        };

        View.OnClickListener incrementButton = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                increment();
            }
        };

        View.OnClickListener decrementButton = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrement();
            }
        };

        Button buttonOrder = findViewById(R.id.order_button);
        buttonOrder.setOnClickListener(orderButton);

        Button buttonIncrement = findViewById((R.id.button_increment));
        buttonIncrement.setOnClickListener(incrementButton);

        Button buttonDecrement = findViewById(R.id.button_decrement);
        buttonDecrement.setOnClickListener(decrementButton);

        TextView priceTextView = findViewById(R.id.price_text_view);
        originalColor = priceTextView.getCurrentTextColor();

    }

    public void increment() {
        mNumberOfCoffees++;
        TextView quantityTextView = findViewById(R.id.quantity_text_view);
        quantityTextView.setText(NumberFormat.getInstance().format(mNumberOfCoffees));
    }

    public void decrement() {
        if (mNumberOfCoffees > 0) {
            mNumberOfCoffees--;
            TextView quantityTextView = findViewById(R.id.quantity_text_view);
            quantityTextView.setText(NumberFormat.getInstance().format(mNumberOfCoffees));
        }
    }

    public int calculatePrice(int quantity){
        int price = 0;
        if (quantity > 0){
            price = quantity * ((PRICE_PER_CUP + PAPER_CUP_CHARGE));
        }
        return price;
    }

    public void finalOrder() {
        if (mNumberOfCoffees <= 0) {
            displayPrice(0);
        } else {
            displayPrice(calculatePrice(mNumberOfCoffees));
        }
    }

    @SuppressLint("SetTextI18n")
    public void createOrderSummary(TextView textView, int number) {
        textView.setText("Name: " + name + "\n" +
                quantity + mNumberOfCoffees + "\n" +
                total + NumberFormat.getCurrencyInstance(new Locale("us", "US")).format(number) + "\n" +
                closeThankYou);
    }

    @SuppressLint("SetTextI18n")
    private void displayPrice(int number) {
        TextView priceTextView = findViewById(R.id.price_text_view);
        if (number > 0) {
            priceTextView.setTextColor(originalColor);
            createOrderSummary(priceTextView, number);
        } else {
            priceTextView.setTextColor(Color.RED);
            priceTextView.setText(NumberFormat.getCurrencyInstance(new Locale("us", "US")).format(number));
        }
    }
}